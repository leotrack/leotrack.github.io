<?php get_header(); ?>
<?php if (!isset($_REQUEST["display"])) { ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="post">
	 <h3 class="storytitle" id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h3>
	<div class="meta"><?php _e("Filed under:"); ?> <?php the_category(',') ?> &#8212; <?php the_author() ?> @ <?php the_date(); ?>,<?php the_time() ?> <?php edit_post_link(__('Edit This')); ?></div>
	
	<div class="storycontent">
		<?php the_content(__('(Read More &raquo;&raquo;&raquo;)')); ?>
	</div>
	
	<div class="postfeedback">
            <?php wp_link_pages(); ?>
            <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?>
	</div>
	
	<!--
	<?php trackback_rdf(); ?>
	-->
</div>
<?php comments_template( is_single() ); // Get wp-comments.php template ?>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>

<?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?>
<?php } else if ($_REQUEST["display"] == "archives") { ?>
	 <h2><?php _e('Archives:'); ?></h2> 
 	<ul>
	 <?php wp_get_archives('type=monthly'); ?>
 	</ul>
<?php } else if ($_REQUEST["display"] == "links") { ?> 
	<h2><?php _e('Links:'); ?></h2> 
	<ul> <?php get_links_list();?></ul> 
<?php } else if ($_REQUEST["display"] == "categories") { ?>
 <h2><?php _e('Categories:'); ?></h2>
	<ul>
	<?php wp_list_cats(); ?>
	</ul>
<?php } else if ($_REQUEST["display"] == "meta") { ?>
	<h2><?php _e('Meta:'); ?></h2>
 	<ul>
		<li><?php wp_register(); ?></li>
		<li><?php wp_loginout(); ?></li>
		<li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>"><?php _e('<abbr title="Really Simple Syndication">RSS</abbr>'); ?></a></li>
		<li><a href="<?php bloginfo('comments_rss2_url'); ?>" title="<?php _e('The latest comments to all posts in RSS'); ?>"><?php _e('Comments <abbr title="Really Simple Syndication">RSS</abbr>'); ?></a></li>
		<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.'); ?>"><abbr title="WordPress">WP</abbr></a></li>
		<?php wp_meta(); ?>
	</ul>
</div>
<?php } get_footer(); ?>
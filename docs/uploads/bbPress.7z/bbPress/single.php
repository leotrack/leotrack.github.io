<?php get_header(); ?>	
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
		<div class="navigation">
			<div class="alignleft"><?php previous_post('&laquo; %','','yes') ?></div>			<div class="alignright"><?php next_post(' % &raquo;','','yes') ?></div>
		</div>

		<div class="post">
	
			<h3 class="storytitle"  id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permalink:'); ?> <?php the_title(); ?>"><?php the_title(); ?></a></h3>
<span class="posttime"><B> <?php the_author_posts_link(); ?> </B><?php _e("Posted"); ?>@<?php the_date(); ?>,<?php the_weekday_date() ?>&#9675;<?php if(function_exists('the_ratings')) { the_ratings(); } ?></span>
			<div class="storycontent">
			<?php the_content(__('More&raquo;')); ?>
<?php wp_link_pages(); ?>
<div class="utwtags"><?php if(function_exists('UTW_ShowTagsForCurrentPost')) { UTW_ShowTagsForCurrentPost("commalist"); } ?></div>
<!-- add bookmarks -->
<center><p><a name="bookmarks"></a><?php if(function_exists('add_bookmarks')) { add_bookmarks(); } ?></p></center>
			</div>

<p><span class="postfeedback"><?php _e("Filed under:"); ?><B><?php the_category(', ') ?></B>,<?php if(function_exists('the_views')) { the_views(); } ?><?php edit_post_link('Edit','<span class="editlink">','</span>'); ?></span></p>
<p class="small">
		<?php comments_rss_link(__('Comments <abbr title="Really Simple Syndication">RSS</abbr>')); ?>
		<?php if ( pings_open() ) : ?>
			&#183; <a href="<?php trackback_url() ?>" rel="trackback"><?php _e('Trackback <abbr title="Uniform Resource Identifier">URI</abbr>'); ?></a>
		<?php endif; ?>
	</p>	</div>
<?php if ($post->comment_status == "open") ?>		
		<?php comments_template(); ?>
<?php endwhile; ?>

<?php else : ?>				
		<h2><?php _e('404 Not Found'); ?></h2>

		<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>

	<?php endif; ?>
</div>
<?php get_footer(); ?>

<!-- begin sidebar -->
<ul id="menu">
<li class="page_item current_page_item"><a href="<?php echo get_settings('siteurl'); ?>/" title="Home">Home</a></li>
<?php wp_list_pages('title_li=&depth=1&'.$page_sort.'&'.$pages_to_exclude)?>    
<li class="page_item"><a href="<?php bloginfo('url'); ?>/?display=categories" title="Category">Category</a></li>
<li class="page_item"><a href="<?php bloginfo('url'); ?>/?display=links" title="Friends & Links">Links</a></li>
<li class="page_item"><a href="<?php bloginfo('url'); ?>/?display=meta" title="Meta">Meta</a></li>
<li class="page_item"><a id="last" href="<?php echo get_option('siteurl'); ?>/wp-admin/" title="Admin">Admin&raquo;</a></li>
<a name="search"></a><div id="search"><form method="get" id="searchform" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<input type="text" value="<?php echo wp_specialchars($s, 1); ?>" name="s" id="s" size="18" />
<input type="submit" id="submit" value="Search" />
</form></div>
</ul>
<!-- end sidebar -->
<!-- begin footer -->
<div id="bbfooter">Powered by <a href="http://wordpress.org">Wordpress</a> <?php echo $wp_version; ?>  - Theme By <a href="http://www.zhu8.net/blog/project/bbpress-theme.html">Zhu8</a> From <a href="http://bbPress.org">bbPress</a><br/>
<!--<?php echo get_num_queries(); ?> queries in <?php timer_stop(1); ?> Seconds.--><a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a>
		and <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>.<br/>Code is Poetry. <a href="javascript:scroll(0,0)">#Top</a></div>
<?php do_action('wp_footer', ''); ?>
<!-- By Zhu8  - http://www.zhu8.net/blog/project/bbpress-theme.html -->
<?php /* "I'm waiting 4 U Xiao Bai" */ ?>
</body>
</html>
<?php
function smarty_function_mttechnoratiurl($args, &$ctx) {
  $entry = $ctx->stash('entry');
  $permalink = $ctx->tag('MTEntryPermalink');
  $link = 'http://technorati.com/faves?add';
  $link .= '?url=' . urlencode(permalink);
  return $link;
}
?>
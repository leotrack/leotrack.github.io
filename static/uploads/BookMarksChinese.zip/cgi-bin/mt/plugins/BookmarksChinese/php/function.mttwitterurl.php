<?php
function smarty_function_mttwitterurl($args, &$ctx) {
  $entry = $ctx->stash('entry');
  $permalink = $ctx->tag('MTEntryPermalink');
  $link = 'http://twitter.com/home/?status=RT&nbsp;%40Zhu8Net:&nbsp;';
  $link .= '' . urlencode($entry['entry_title']);
  $link .= '&nbsp;' . urlencode($permalink);
  return $link;
}
?>
#!/usr/bin/perl -w
#
# Copyright 2006-2008, Six Apart, Ltd.
# Licensed under the same terms as Perl itself.

package MT::Plugin::BookmarksChinese;

use strict;
use MT;

use vars qw( $VERSION $plugin );
$VERSION = '1.0';

eval {
    $plugin = new MT::Plugin({
	name            => 'Bookmarks Chinese',
        version         => $VERSION,
	author_name     => "Zhu8",
	author_link     => "http://www.zhu8.net/",
	plugin_link     => "http://www.zhu8.net/blog/2009/06/bookmarks-chinese.html",
	description     => "Bookmarks Plugin For Movable Type Chinese User.",
    });
    MT->add_plugin($plugin);
};

require MT::Template::Context;
require MT::Util;

MT::Template::Context->add_tag(AddToAnyURL => sub {
    my $ctx = shift;
    my $entry = $ctx->stash('entry');
    my $link = 'http://www.addtoany.com/bookmark';
    $link .= '?linkname=' . MT::Util::encode_url($entry->title);
    $link .= '&amp;linkurl=' . MT::Util::encode_url($entry->permalink);
    return $link;
});
MT::Template::Context->add_tag(TechnoratiURL => sub { 
    my $ctx = shift;
    my $entry = $ctx->stash('entry');
    my $link = 'http://technorati.com/faves?add';
    $link .= '?url=' . MT::Util::encode_url($entry->permalink);
    return $link;
});
MT::Template::Context->add_tag(DiggURL => sub { 
    my $ctx = shift;
    my $entry = $ctx->stash('entry');
    my $link = 'http://digg.com/submit?phase=2';
    $link .= '&amp;url=' . MT::Util::encode_url($entry->permalink);
    $link .= '&amp;title=' . MT::Util::encode_url($entry->title);
    $link .= '&amp;bodytext=' . MT::Util::encode_url($entry->excerpt) if $entry->excerpt;
    $link .= '&amp;topic=';
    return $link;
});
MT::Template::Context->add_tag(DeliciousURL => sub { 
    my $ctx = shift;
    my $entry = $ctx->stash('entry');
    my $link = 'http://delicious.com/post?v=5';
    $link .= '&amp;url=' . MT::Util::encode_url($entry->permalink);
    $link .= '&amp;title=' . MT::Util::encode_url($entry->title);
    return $link;
});
# http://friendfeed.com/?url=http://www.zhu8.net&title=Zhu8's Web
MT::Template::Context->add_tag(FriendFeedURL => sub { 
    my $ctx = shift;
    my $entry = $ctx->stash('entry');
    my $link = 'http://friendfeed.com/?';
    $link .= 'url=' . MT::Util::encode_url($entry->permalink);
    $link .= '&amp;title=' . MT::Util::encode_url($entry->title);
    return $link;
});
# http://twitter.com/home/?status=RT @Zhu8Net: Zhu8's Web http://www.zhu8.net/
MT::Template::Context->add_tag(TwitterURL => sub { 
    my $ctx = shift;
    my $entry = $ctx->stash('entry');
    my $link = 'http://twitter.com/home/?status=RT&nbsp;%40Zhu8Net:&nbsp;';
    $link .= '' . MT::Util::encode_url($entry->title);
    $link .= '&nbsp;' . MT::Util::encode_url($entry->permalink);
    return $link;
});
# http://www.google.com/bookmarks/mark?op=add&bkmk=http://www.zhu8.net&title=Zhu8's+Web
MT::Template::Context->add_tag(GoogleURL => sub { 
    my $ctx = shift;
    my $entry = $ctx->stash('entry');
    my $link = 'http://www.google.com/bookmarks/mark?op=add';
    $link .= '&amp;title=' . MT::Util::encode_url($entry->title);
    $link .= '&amp;bkmk=' . MT::Util::encode_url($entry->permalink);
    return $link;
});
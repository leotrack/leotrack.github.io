描述：

BookmarksChinese是我在使用了一些如addthis.com的按钮之后，发现对中文支持很差，所以弄的一个中文化的书签插件如果你还需要其他的按钮，请自行参考开发即可。
作者信息：Zhu8  (http://www.zhu8.net)
插件地址：http://www.zhu8.net/blog/2009/06/bookmarks-chinese.html
插件版本：1.0 Final (2009.6.4)

插件结构：

 mt-static/
            plugins/
                   BookmarksChinese/
                               style.css
			       images/
			              addtoany.png
				      google.png
				      digg.png
				      technorati.png
				      delicious.png
				      friendfeed.png
				      twitter.png

 cgi-bin/mt/
            plugins/
                   BookmarksChinese/
                               BookmarksChinese.pl
                               php/
                                   function.mtaddtoanyurl.php
                                   function.mtgoogleurl.php
                                   function.mtdiggurl.php
                                   function.mttechnoratiurl.php
                                   function.mtdeliciousurl.php
                                   function.mtfriendfeedurl.php
                                   function.mttwitterurl.php


模板标签：

  <$MTAddToAnyURL$>
  <$MTDiggURL$>
  <$MTDeliciousURL$>
  <$MTFriendFeedURL$>
  <$MTGoogleURL$>
  <$MTTechnoratiURL$>
  <$MTTwitterURL$>

例子：

  <a class="delicious" href="<$MTDeliciousURL$>" title="收藏到美味书签" target="_blank"></a>
  使用方法及详细使用说明请参见上方插件地址。
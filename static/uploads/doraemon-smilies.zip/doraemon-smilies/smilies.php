<?php

if (!get_option('use_smilies')) {
    update_option('use_smilies', 1);
}

add_action('admin_menu', 'dora_add_custom_box');

function dora_add_custom_box() {
	add_meta_box( 'dorabox', __('Smilies', 'custom_smilies'), 'dora_inner_custom_box', 'post', 'normal');
	add_meta_box( 'dorabox', __('Smilies', 'custom_smilies'), 'dora_inner_custom_box', 'page', 'normal');
}

add_action('comment_form', 'dora_print_smilies');

function dora_inner_custom_box() {
	
	?>
    <script type="text/javascript">
    function grin(tag) {
    	var myField;
    	tag = ' ' + tag + ' ';
    	if (document.getElementById('content') && document.getElementById('content').style.display != 'none' && document.getElementById('content').type == 'textarea') {
    		myField = document.getElementById('content');
            if (document.selection) {
        		myField.focus();
        		sel = document.selection.createRange();
        		sel.text = tag;
        		myField.focus();
        	}
        	else if (myField.selectionStart || myField.selectionStart == '0') {
        		var startPos = myField.selectionStart;
        		var endPos = myField.selectionEnd;
        		var cursorPos = endPos;
        		myField.value = myField.value.substring(0, startPos)
        					  + tag
        					  + myField.value.substring(endPos, myField.value.length);
        		cursorPos += tag.length;
        		myField.focus();
        		myField.selectionStart = cursorPos;
        		myField.selectionEnd = cursorPos;
        	}
        	else {
        		myField.value += tag;
        		myField.focus();
        	}
    	} else {
            tinyMCE.execCommand('mceInsertContent', false, tag);
        }
    }
    </script><?php
            $smilies = dora_load_existing_smilies();
            $url = get_bloginfo('wpurl').'/wp-includes/images/smilies';


        	foreach ($smilies as $k => $v) {
            	echo "<img src='{$url}/{$k}' alt='{$v}' title='{$v}' onclick='grin(\"{$v}\")' class='wp-smiley-select' /> ";
        	}

}

function dora_get_all_smilies() {
    if ($handle = opendir('../wp-includes/images/smilies')) {
        while (false !== ($file = readdir($handle))) {

            if ($file != '.' && $file != '..') {
                $smilies[] = $file;
            }
        }
        closedir($handle);
    }
    return $smilies;
}

function dora_load_existing_smilies() {
    global $wpsmiliestrans;
    return array_flip($wpsmiliestrans);
}

function dora_save_smilies($array) {
    if (!is_array($array)) {
        return;
    }

    $handle = fopen('../wp-content/plugins/doraemon-smilies/init.php', 'w');

    foreach ($array as $k => $v) {

        $array[$k] = trim(str_replace(array('\'','\\', '"'), '', $v));
    }

    $header = <<<HERE
<?php
\$wpsmiliestrans = array(\n
HERE;

    fwrite($handle, $header);

    $array = array_flip($array);

    foreach ($array as $k => $v) {

        $array[$k] = $v = str_replace('|', '.', $v);

        if (!in_array($v, array('update-smilies', 'page')) && !in_array($k, array('', 'QAD'))) {
            fwrite($handle, "\t'{$k}' => '{$v}',\n");
        }
    }

    fwrite($handle, ');');

    fclose($handle);

    return $array;
}

function doram_comment_form() {
    dora_print_smilies();
}

function dora_all_smilies() {
	global $wpsmiliestrans;
	$url = get_bloginfo('wpurl').'/wp-includes/images/smilies';
	foreach ($wpsmiliestrans as $k => $v) {
		$smilies[$k] = "$url/$v";
	}
	return $smilies;
}
function dora_print_smilies() {
?>
    <script type="text/javascript">
    function grin(tag) {
    	var myField;
    	tag = ' ' + tag + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
    		myField = document.getElementById('comment');
    	} else {
    		return false;
    	}
    	if (document.selection) {
    		myField.focus();
    		sel = document.selection.createRange();
    		sel.text = tag;
    		myField.focus();
    	}
    	else if (myField.selectionStart || myField.selectionStart == '0') {
    		var startPos = myField.selectionStart;
    		var endPos = myField.selectionEnd;
    		var cursorPos = endPos;
    		myField.value = myField.value.substring(0, startPos)
    					  + tag
    					  + myField.value.substring(endPos, myField.value.length);
    		cursorPos += tag.length;
    		myField.focus();
    		myField.selectionStart = cursorPos;
    		myField.selectionEnd = cursorPos;
    	}
    	else {
    		myField.value += tag;
    		myField.focus();
    	}
    }
    
    function moreSmilies() {
    	document.getElementById('wp-smiley-more').style.display = 'inline';
    	document.getElementById('wp-smiley-toggle').innerHTML = '<a href="javascript:lessSmilies()">&laquo;&nbsp;less</a></span>';
    }
    
    function lessSmilies() {
    	document.getElementById('wp-smiley-more').style.display = 'none';
    	document.getElementById('wp-smiley-toggle').innerHTML = '<a href="javascript:moreSmilies()">more&nbsp;&raquo;</a>';
    }
    </script>
<?php
    $smilies = dora_load_existing_smilies();
    $url = get_bloginfo('wpurl').'/wp-includes/images/smilies';
    $list = get_option('dora_list');            

    if ($list == '') {
	    foreach ($smilies as $k => $v) {
	        echo "<img src='{$url}/{$k}' alt='{$v}' title='{$v}' onclick='grin(\"{$v}\")' class='wp-smiley-select' /> ";
	    }
    } else {
    	$display = explode(',', $list);
    	$smilies = array_flip($smilies);
    	foreach ($display as $v) {
    		$v = trim($v);
    		echo "<img src='{$url}/{$smilies[$v]}' alt='{$v}' title='{$v}' onclick='grin(\"{$v}\")' class='wp-smiley-select' /> ";
    		unset($smilies[$v]);    		
    	}
    	echo '<span id="wp-smiley-more" style="display:none">';
    	foreach ($smilies as $k => $v) {
    		echo "<img src='{$url}/{$v}' alt='{$k}' title='{$k}' onclick='grin(\"{$k}\")' class='wp-smiley-select' /> ";
    	}
    	echo '</span> <span id="wp-smiley-toggle"><a href="javascript:moreSmilies()">more&nbsp;&raquo;</a></span>';
    }            
}
?>
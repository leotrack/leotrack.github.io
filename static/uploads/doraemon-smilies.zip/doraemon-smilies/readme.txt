
:::: About ::::

Plugin Name: Doraemon Smiles For Wordpress
Plugin URI: http://www.zhu8.net/project/doraemon-smilies.html
Description: Use Doraemon Smilies in your wordpress blog's posts & comments.More: <a href="http://www.zhu8.net/project/doraemon-smilies.html">Usage</a>.
Author: Zhu8
Version: 1.0
Author URI: http://www.zhu8.net
Requires at least: 2.5

:::: Description ::::

Use Doraemon Smilies in your wordpress blog's posts & comments.
Usage: <a href="http://www.zhu8.net/project/doraemon-smilies.html">Usage</a>.


:::: Installation ::::

1. Download and extract "doraemon-smilies.zip";
2. Upload the directory "doraemon-smilies" to the "/wp-content/plugins" directory. Upload "smilies" folder to the "/wp-includes/images" directory;
2. Activate "Doraemon Smilies For Wordpress" in "Admin Panel>plugin";
3. All Done!Enjoy!
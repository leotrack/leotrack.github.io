<?php
/*
Plugin Name: Doraemon Smilies For Wordpress
Plugin URI: http://www.zhu8.net/project/doraemon-smilies.html
Description: Make your posts and comments using Doraemon Smilies.More: <a href="http://www.zhu8.net/project/doraemon-smilies.html">Usage</a>.
Author: Zhu8
Version: 1.0
Author URI: http://www.zhu8.net
*/

include_once('init.php');
include('smilies.php');
?>
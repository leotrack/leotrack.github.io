<?php
/*
Plugin Name: Add Bookmarks
Version: 0.2
Plugin URI: http://www.zhu8.net/blog/2006/09/03/wordpress_plugin_add_bookmarks/
Description: 在你的文章下加入添加到书签或网摘的代码，参考Thomas McMahon的插件<a href="http://www.twistermc.com/shake/wordpress-social.php" target="blank">Social Bookmark Links</a>修改，可选择文字链接或图标链接，若喜欢还可以自己添加。
Author: Zhu8
Author URI: http://www.zhu8.net/
*/

function add_bookmarks() {

// 以下可以编辑. //
// 引号需要转义，否则无法正常使用 (使用 \")

$createKind = "icon";  // links : 文字链接 - icon : 图标链接

$beforeall = "<b>收藏</b> "; // 你想显示在所有书签前面的  
$beforeeach = "&nbsp;"; // 你想显示在每个书签前面的
$aftereach = "&nbsp;"; // 你想显示在每个书签后面的
$afterall = ""; // 你想显示在所有书签后面的

// 你想显示哪个书签？
// 0=不显示 1=显示

$a0 = "1"; // Blogmarks
$a1 = "1"; // del.icio.us
$a2 = "1"; // Furl
$a3 = "1"; // Yahoo!收藏
$a4 = "1"; //365key | 天天网摘
$a5 = "1"; //Google Bookmarks | Google书签
$a6 = "1"; //百度搜藏


// 以下在你不能完全控制的情况下最好不要编辑 //

if ($createKind == "links") {
$button0 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://blogmarks.net/my/marks,new?mini=1'+'&title='+encodeURIComponent(document.title)+'&url='+encodeURIComponent(location.href)+'&summary='+encodeURIComponent(q)+'&via='+encodeURIComponent(r),'blogmarks','location=no,toolbar=no,scrollbars=yes,width=350,height=450,status=no'));\" title=\"加入到 Blogmarks\">Blogmarks</a>";
$button1 = "<a href=\"http://del.icio.us/post\" onclick=\"window.open('http://del.icio.us/post?v=4&amp;noui&amp;jump=close&amp;url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title), 'delicious','toolbar=no,width=700,height=400'); return false;\" title=\"加入到 美味书签\">del.icio.us</a>";
$button2 = "<a href=\"javascript:(function(){var%20s=document.createElement('script');s.setAttribute('src','http://www.furl.net/resources/furlItComplete.jsp');s.setAttribute('type','text/javascript');document.getElementsByTagName('head')[0].appendChild(s);})();\" title=\"加入到 Furl\">Furl</a>";
$button3 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://myweb.cn.yahoo.com/popadd.html?url='+encodeURIComponent(document.location.href)+'&title='+encodeURIComponent(document.title), 'Yahoo','scrollbars=yes,width=780,height=455,left=80,top=80,status=yes,resizable=yes'));\" title=\"加入到 雅虎收藏\"><font color=\"red\">Yahoo!</font><sup>+</sup></a>";
$button4 = "<a href=\"javascript:d=document;t=d.selection?(d.selection.type!='None'?d.selection.createRange().text:''):(d.getSelection?d.getSelection():'');void(keyit=window.open('http://www.365key.com/storeit.aspx?t='+escape(d.title)+'&u='+escape(d.location.href)+'&c='+escape(t),'keyit','scrollbars=no,width=475,height=575,left=75,top=20,status=no,resizable=yes'));keyit.focus();\" title=\"功能强大的网络收藏夹，一秒钟操作就可以轻松实现保存带来的价值、分享带来的快乐\"><font color=\"DarkOrchid\">365K<font color=\"#57c200\">e</font>y</font></a>";
$button5 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://www.google.com/bookmarks/mark?op=add&bkmk='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title),'Google','location=no,toolbar=no,scrollbars=yes,width=700,height=450,status=no'));\" title=\"加入到 Google 书签\">Google书签</a>";
$button6 = "<a href=\"javascript:u=location.href;t=document.title;c = %22%22 + (window.getSelection ? window.getSelection() : document.getSelection ? document.getSelection() : document.selection.createRange().text);var url=%22http://cang.baidu.com/do/add?it=%22+encodeURIComponent(t)+%22&iu=%22+encodeURIComponent(u)+%22&dc=%22+encodeURIComponent(c)+%22&fr=ien#nw=1%22;window.open(url,%22_blank%22,%22scrollbars=no,width=600,height=450,left=75,top=20,status=no,resizable=yes%22); void 0\" title=\"加入到百度搜藏\">百度搜藏</a>";

$buttons = 7; // 书签的数量再加上1
$counter = 0;
$button = '$button';

echo ("<a href=\"http://www.zhu8.net/blog/2006/09/03/wordpress_plugin_add_bookmarks/\"><img src=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/add2myweb.gif\" border=\"0\" alt=\"plugin main page\"></a> ");
echo ($beforeall);
while ($counter < $buttons) {
	if (${'a' . $counter}) {
	// prints rss button
	$printbutton = ${'button' . $counter};
	echo ($beforeeach);
	echo($printbutton."\n");
	echo ($aftereach);
	}
	$counter = $counter+1;
}
echo ($afterall);
}
if ($createKind == "icon") {
$button0 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://blogmarks.net/my/marks,new?mini=1'+'&title='+encodeURIComponent(document.title)+'&url='+encodeURIComponent(location.href)+'&summary='+encodeURIComponent(q)+'&via='+encodeURIComponent(r),'blogmarks','location=no,toolbar=no,scrollbars=yes,width=350,height=450,status=no'));\" title=\"加入到 Blogmarks\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/blogmarks.png\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button1 = "<a href=\"http://del.icio.us/post\" onclick=\"window.open('http://del.icio.us/post?v=4&amp;noui&amp;jump=close&amp;url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title), 'delicious','toolbar=no,width=700,height=400'); return false;\" title=\"加入到 美味书签\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/delicious.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button2 = "<a href=\"javascript:(function(){var%20s=document.createElement('script');s.setAttribute('src','http://www.furl.net/resources/furlItComplete.jsp');s.setAttribute('type','text/javascript');document.getElementsByTagName('head')[0].appendChild(s);})();\" title=\"加入到 Furl\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/furl.png\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button3 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://myweb.cn.yahoo.com/popadd.html?url='+encodeURIComponent(document.location.href)+'&title='+encodeURIComponent(document.title), 'Yahoo','scrollbars=yes,width=780,height=455,left=80,top=80,status=yes,resizable=yes'));\" title=\"加入到 雅虎收藏\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/yahoo.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button4 = "<a href=\"javascript:d=document;t=d.selection?(d.selection.type!='None'?d.selection.createRange().text:''):(d.getSelection?d.getSelection():'');void(keyit=window.open('http://www.365key.com/storeit.aspx?t='+escape(d.title)+'&u='+escape(d.location.href)+'&c='+escape(t),'keyit','scrollbars=no,width=475,height=575,left=75,top=20,status=no,resizable=yes'));keyit.focus();\" title=\"功能强大的网络收藏夹，一秒钟操作就可以轻松实现保存带来的价值、分享带来的快乐\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/365key.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button5 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://www.google.com/bookmarks/mark?op=add&bkmk='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title),'Google','location=no,toolbar=no,scrollbars=yes,width=700,height=450,status=no'));\" title=\"加入到 Google 书签\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/google.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button6 = "<a href=\"javascript:u=location.href;t=document.title;c = %22%22 + (window.getSelection ? window.getSelection() : document.getSelection ? document.getSelection() : document.selection.createRange().text);var url=%22http://cang.baidu.com/do/add?it=%22+encodeURIComponent(t)+%22&iu=%22+encodeURIComponent(u)+%22&dc=%22+encodeURIComponent(c)+%22&fr=ien#nw=1%22;window.open(url,'_blank','scrollbars=no,width=600,height=450,left=75,top=20,status=no,resizable=yes'); void 0\" title=\"加入到百度搜藏\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/baidu.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";


$buttons = 7; // 图标的数量再加上1
$counter = 0;
$button = '$button';

echo ("<a href=\"http://www.zhu8.net/blog/2006/09/03/wordpress_plugin_add_bookmarks/\"><img src=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/add2myweb.gif\" border=\"0\" alt=\"plugin main page\"></a> ");
echo ($beforeall);
while ($counter < $buttons) {
	if (${'a' . $counter}) {
	// prints rss button
	$printbutton = ${'button' . $counter};
	echo ($beforeeach);
	echo($printbutton."\n");
	echo ($aftereach);
	}
	$counter = $counter+1;
}
echo ($afterall);
}
}
?>
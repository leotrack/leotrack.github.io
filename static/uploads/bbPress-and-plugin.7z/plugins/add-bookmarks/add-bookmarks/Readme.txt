﻿    * 插件名称：Add Bookmarks

    * 插件版本：0.1（0.2 Updated on 2006.11.28）

    * 插件作者：Zhu8(http://www.zhu8.net/blog/)

    * 插件描述：

在你的文章下加入添加到书签或网摘的代码，参考Thomas McMahon插件Social Bookmark Links修改，可选择文字链接或图标链接，若喜欢还可以自己添加。
Update On 2006/9/27：更新了图片的链接问题，使用".get_settings('siteurl')."使链接在更新Blog地址的时候不会出错。

    * 插件安装：1) 下载插件：add-bookmarks.rar

    * 2) 打开 add-bookmarks.php 并在文本编辑器中配置好。

    * 3) 你不想使用的书签请将 0 改成 1，反之亦然。

例子：$a4 = “1″; //365key | 天天网摘 - 这就是说你已经设置成使用365key了。

    * 4) 设置书签的显示方式

$createKind = “icon”; // links : 文字链接 - icon : 图标链接

文字链接示例：
»» 文字链接
图标链接示例：
»» 图标链接
$beforeall = “收藏 “; // 你想显示在所有书签前面的
$beforeeach = ” [ “; // 你想显示在每个书签前面的
$aftereach = ” ] “; // 你想显示在每个书签后面的
$afterall = “”; // 你想显示在所有书签后面的
// 可以使用HTML标签，但不能使用(”)哦！

    * 5) 上传文件夹add-bookmarks到你的插件目录（注意：包括icon文件夹和add-bookmarks.php）。

    * 6) 在管理页面激活插件。

    * 7) 将下面的代码放到你想显示加入书签或网摘的位置：

<?php if(function_exists('add_bookmarks')) { add_bookmarks(); } ?>

- 我是放置在single.php中例如 <p class="postmetadata"> 前面的，仅供参考。
- 如果你停用了该插件，可以将该代码移除。（因为使用了if语句，所以不移出也不会影响其他正常功能的 :em06: ）-Update On 2006.12.22

    * Tips(小提示)：

Yahoo!我已经修改成Yahoo!中国的Yahoo!收藏+，更符合国人习惯；你如果想修改图标内容，图标均在icon目录下，增加或修改的图标请注意在add-bookmarks.php中也要记得修改图标的源文件地址。
Update@2006/09/05
将所使用的五个书签的代码做了一次更新，确保每个对中文正确识别。其中Furl对中文的支持最不好，我使用其他人所最常使用的代码http://www.furl.net/storeIt.jsp?u='+encodeURIComponent(location.href)
+'&t='+encodeURIComponent(document.title)+'等均会使中文标题变成乱码，所以我最后还是选择了一个弹出窗口的，可能使用窗口block的会有一定影响。
更多书签网站请参考：网摘大全1016最新整理版　(rss8.net 木木牛牛整理)
另一种方式请参考：无需插件 给你的BLOG手动添加 网摘 代码　图标下载。
欢迎你使用Trackback告知我你使用了该插件 :-)
Updated on 2006.11.28
加入 百度搜藏：

    百度搜藏是免费的网络收藏夹，为您提供：
    全文收藏
    不仅能收藏网址，更能自动收藏全文
    快速查找
    在您收藏的海量信息中，快速、准确地找到所需资料
    网页快照
    不必担心网页链接失效，您可以通过“快照”快速浏览页面内容
    轻松便捷
    只需连接互联网，就能随时随地收藏和使用
    分享资源
    和朋友分享自己喜欢的网址，或享用他人的收藏
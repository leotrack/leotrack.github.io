<?php /*

Plugin Name: Quote Comment
Plugin URI: http://www.viper007bond.com/wordpress-plugins/quote-comment/
Description: Creates a function that outputs a link that allows commenters to click it and quote the selected comment. Configure via the <a href="options-general.php?page=quote_comment.php">options page</a>.
Version: 2.0
Author: Viper007Bond
Author URI: http://www.viper007bond.com/

See the plugin's URI for usage and installation instructions.

*/

##### BEGIN ADVANCED USER CONFIG #####

// These are the placeholders for comments
// If you change these, it'll break past quoted comments, so change them before installing
// Format = $before_id then the comment number and then $after_id

$before_id = "[Comment ID #"; // Default is "[Comment ID #"
$after_id = " Will Be Quoted Here]"; // Default is " Will Be Quoted Here]"

##### END ADVANCED USER CONFIG #####
##### DON'T EDIT ANYTHING PAST HERE!!! #####


// These next items is how this plugin hooks into WordPress
add_action('admin_menu', 'quotecomment_addoptionspage'); // Tell WordPress about the options page
add_filter('comment_text', 'add_quoted_comments', 1); // Process comments and replace quoted comments with contents
// Set the parameters of the options page
function quotecomment_addoptionspage() {
	if (function_exists('add_options_page'))
		add_options_page(__("Quote Comment Configuration"), __("Quote Comment"), 6, basename(__FILE__), 'quotecomment_optionspage');
}


// Create the default settings
$default_settings = array(
	'link_type' => 'text',
	'link_contents' => __('Quote'),
	'link_title' => __('Click this link to quote this comment in your reply'),
	'before_link' => ' [ ',
	'after_link' => ' ]',
	'byline' => __('<em>[name] on [date] at [time] said:</em>'),
	'byline_link_title' => __('Click here to view the original comment'),
	'byline_location' => 'before',
	'comments_other_posts' => 'no',
	'allow_nested_quotes' => 'yes',
);
// Set the default comment form anchor depending on the WordPress version
$version = (int) get_bloginfo('version');
if ($version > 2) $default_settings['comment_form_anchor'] = 'respond';
else $default_settings['comment_form_anchor'] = 'commentform';

// Handle option page form submission
if ($_POST && $_GET['page'] == basename(__FILE__)) {
	if ($_POST['defaults']) {
		update_option('quote_comment', $default_settings);
		$message = __('Options reset to defaults.');
	} else {
		update_option('quote_comment', array(
			'link_type' => $_POST['link_type'],
			'link_contents' => $_POST['link_contents'],
			'link_title' => $_POST['link_title'],
			'before_link' => $_POST['before_link'],
			'after_link' => $_POST['after_link'],
			'comment_form_anchor' => $_POST['comment_form_anchor'],
			'byline' => $_POST['byline'],
			'byline_link_title' => $_POST['byline_link_title'],
			'byline_location' => $_POST['byline_location'],
			'comments_other_posts' => $_POST['comments_other_posts'],
			'allow_nested_quotes' => $_POST['allow_nested_quotes'],
		));
		$message = __('Options saved.');
	}
}

// Get the current settings, set to default if they don't exist
$qc_settings = get_option('quote_comment');
if (!is_array($qc_settings)) {
	// Put the default settings into the database
	update_option('quote_comment', $default_settings);

	// Now set the settings to the default ones
	$qc_settings = $default_settings;
}


// The options page
function quotecomment_optionspage() {
	global $qc_settings, $message;

	if ($message) echo '<div id="message" class="updated fade"><p><strong>' . $message . "</strong></p></div>\n\n";

	?>

<div class="wrap">
	<h2><?php _e("Quote Comment Configuration"); ?></h2>

	<form name="qc_config" method="post" action="">

	<fieldset class="options">
		<legend><?php _e("Quote Link Defaults"); ?></legend>

		<p><?php _e("Set the defaults for the quote link here. Note that you can override these via the <code>quote_comment()</code> function when you use it in your template."); ?></p>

		<table width="100%" cellspacing="2" cellpadding="5" class="editform">
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Link Type:"); ?>
				</th>
				<td>
					<select name="link_type" id="link_type">
						<option value="text"<?php if ($qc_settings['link_type'] == 'text') echo ' selected="selected"'; ?>><?php _e("Text"); ?></option>
						<option value="image"<?php if ($qc_settings['link_type'] == 'image') echo ' selected="selected"'; ?>><?php _e("An Image"); ?></option>
					</select><br />
					<?php _e("What type of item do you want the user to click?"); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Link Contents:"); ?>
				</th>
				<td>
					<input name="link_contents" type="text" id="link_contents" size="50" style="width: 60%;" value="<?php echo htmlspecialchars($qc_settings['link_contents'], ENT_QUOTES); ?>" /><br />
					<?php _e("The text or image <strong>URL</strong> (a full URL is best) to use for the link."); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Link Title:"); ?>
				</th>
				<td>
					<input name="link_title" type="text" id="link_title" size="50" style="width: 60%;" value="<?php echo htmlspecialchars($qc_settings['link_title'], ENT_QUOTES); ?>" /><br />
					<?php _e("When the user hovers over the link item, this is the text they'll see."); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Before Link:"); ?>
				</th>
				<td>
					<input name="before_link" type="text" id="before_link" size="50" style="width: 60%;" value="<?php echo htmlspecialchars($qc_settings['before_link'], ENT_QUOTES); ?>" /><br />
					<?php _e("Anything you want to display before the link."); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("After Link:"); ?>
				</th>
				<td>
					<input name="after_link" type="text" id="after_link" size="50" style="width: 60%;" value="<?php echo htmlspecialchars($qc_settings['after_link'], ENT_QUOTES); ?>" /><br />
					<?php _e("Anything you want to display after the link."); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Comment Form Anchor:"); ?>
				</th>
				<td>
					#<input name="comment_form_anchor" type="text" id="comment_form_anchor" size="50" style="width: 60%;" value="<?php echo htmlspecialchars($qc_settings['comment_form_anchor'], ENT_QUOTES); ?>" /><br />
					<?php _e("The HTML anchor for your comment form. You shouldn't need to change this.<br />\nDefault values are <code>commentform</code> in WP v1.5.x and <code>respond</code> for WP v2.0.x."); ?>
				</td>
			</tr>
		</table>
	</fieldset>
	<fieldset class="options">
		<legend><?php _e("Quoted Comment Display Configuration"); ?></legend>

		<p><?php _e("Configure here how comments that people quote show up on your blog."); ?></p>

		<table width="100%" cellspacing="2" cellpadding="5" class="editform">
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Byline:"); ?>
				</th>
				<td>
					<input name="byline" type="text" id="byline" size="50" style="width: 60%;" value="<?php echo htmlspecialchars($qc_settings['byline'], ENT_QUOTES); ?>" /><br />
					<?php _e("How you want the byline of the quoted comment to show up.<br />\nSee below for the substitution items you can use."); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Byline Link Title:"); ?>
				</th>
				<td>
					<input name="byline_link_title" type="text" id="byline_link_title" size="50" style="width: 60%;" value="<?php echo htmlspecialchars($qc_settings['byline_link_title'], ENT_QUOTES); ?>" /><br />
					<?php _e("The <code>title</code> for the link to the original comment."); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Byline Location:"); ?>
				</th>
				<td>
					<select name="byline_location" id="byline_location">
						<option value="before"<?php if ($qc_settings['byline_location'] == 'before') echo ' selected="selected"'; ?>><?php _e("Before"); ?></option>
						<option value="after"<?php if ($qc_settings['byline_location'] == 'after') echo ' selected="selected"'; ?>><?php _e("After"); ?></option>
					</select><br />
					<?php _e("Do you want the byline to show up before or after the quoted comment?"); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Comments From Other Posts?"); ?>
				</th>
				<td>
					<select name="comments_other_posts" id="comments_other_posts">
						<option value="no"<?php if ($qc_settings['comments_other_posts'] == 'no') echo ' selected="selected"'; ?>><?php _e("No"); ?></option>
						<option value="yes"<?php if ($qc_settings['comments_other_posts'] == 'yes') echo ' selected="selected"'; ?>><?php _e("Yes"); ?></option>
					</select><br />
					<?php _e("Do you want to allow comments from other posts to be quoted?<br />\ni.e. can comment on post A can be quoted on post B?"); ?>
				</td>
			</tr>
			<tr valign="top">
				<th width="33%" scope="row">
					<?php _e("Allow Nested Quotes?"); ?>
				</th>
				<td>
					<select name="allow_nested_quotes" id="comments_other_posts">
						<option value="yes"<?php if ($qc_settings['allow_nested_quotes'] == 'yes') echo ' selected="selected"'; ?>><?php _e("Yes"); ?></option>
						<option value="no"<?php if ($qc_settings['allow_nested_quotes'] == 'no') echo ' selected="selected"'; ?>><?php _e("No"); ?></option>
					</select><br />
					<?php _e("When someone quotes a comment that has another comment quoted in it,<br />should the quote inside the comment to be quoted show up?"); ?>
				</td>
			</tr>
		</table>

		<p><?php _e("Listed below are the substitution items that you can use for the byline:"); ?></p>

		<table id="substitution_table" width="50%" cellpadding="3" cellspacing="3" align="center">
			<tr> 
				<th scope="col" width="25%"><?php _e("This..."); ?></th>
				<th scope="col"><?php _e("Gets Replaced By This"); ?></th>
			</tr>
			<tr class='alternate' align="center">
				<td><code>[name]</code></td>
				<td><?php _e("Commenter's name"); ?></td>
			</tr>
			<tr align="center">
				<td><code>[date]</code></td>
				<td>
					<?php _e("The date of the quoted comment, in the<br />\nformat as defined in your WP options"); ?>
				</td>
			</tr>
			<tr class='alternate' align="center">
				<td><code>[time]</code></td>
				<td>
					<?php _e("The time of the quoted comment, in the<br />\nformat as defined in your WP options"); ?>
				</td>
			</tr>
			<tr align="center">
				<td><code>[dt <?php _e("FORMAT"); ?>]</code></td>
				<td>
					<?php _e("The date and/or time of the quoted comment,<br />\nin a custom format. See <a href='http://codex.wordpress.org/Formatting_Date_and_Time'>this page</a> for help."); ?>
				</td>
			</tr>
		</table>
	</fieldset>

	<p class="submit">
		<input type="submit" name="defaults" value="&laquo; <?php _e("Reset to Defaults"); ?>" style="float: left;" />
		<input type="submit" name="save" value="<?php _e("Update Options") ?> &raquo;" />
	</p>

	</form>
</div>

<?php
} // End options page


// The template function
function quote_comment($linkcontents = '', $beforelink = '', $afterlink = '', $linktitle = '') {
	global $qc_settings, $comment, $post, $before_id, $after_id;

	// Only do stuff is the comments are open
	if ($post->comment_status != 'open') return;

	// Make sure $comment is set, i.e. we're within the comment loop
	if (!isset($comment)) {
		_e("The quote comment function must be used within the comment loop!");
		return;
	}


	// Handle any settings that were passed via the function itself
	if (!$linkcontents) $linkcontents = $qc_settings['link_contents'];
	if (!$beforelink) $beforelink = $qc_settings['before_link'];
	if (!$afterlink) $afterlink = $qc_settings['after_link'];
	if (!$linktitle) $linktitle = $qc_settings['link_title'];

	
	// Now echo out the link
	echo $beforelink . "<a href='#" . $qc_settings['comment_form_anchor'] . "' title='" . $linktitle . "' onclick=\"document.getElementById('comment').value += '" . htmlspecialchars($before_id, ENT_QUOTES) . $comment->comment_ID . htmlspecialchars($after_id, ENT_QUOTES) . '\n\n\'">';
	
	if ($qc_settings['link_type'] == 'image') echo '<img src="' . $qc_settings['link_contents'] . '" alt="' . $linktitle . '" />';
	else echo $linkcontents;

	echo '</a>' . $afterlink;
}

// Place the actual comment as a quote where need be
function add_quoted_comments($content = '') {
	global $qc_settings, $post, $wpdb, $before_id, $after_id;

	while (strpos($content, $before_id) !== FALSE) {
		// Get the ID to be quoted
		$start_of_id = strpos($content, $before_id) + strlen($before_id); // Where the ID starts
		$end_of_id = strpos($content, $after_id); // Where the ID ends
		$comment_id = (int) substr($content, $start_of_id, $end_of_id - $start_of_id);

		// Get the comment from the database
		$comment = $wpdb->get_row("SELECT comment_ID, comment_post_ID, comment_approved, comment_author, comment_date, comment_content FROM $wpdb->comments WHERE comment_ID = $comment_id");

		// Make sure we will be using an acceptable comment
		if (!$comment->comment_ID) $quoted_comment = "<em>" . __("<strong>ERROR:</strong> Cannot quote comment ID #") . $comment_id . __(" as it can't be found in the database.") . "</em>";
		elseif ($comment->comment_approved == '0') $quoted_comment = "<em>" . __("<strong>ERROR:</strong> Cannot quote comment ID #") . $comment_id . __(" as it is in the admin moderation queue.") . "</em>";
		elseif ($comment->comment_approved == 'spam') $quoted_comment = "<em>" . __("<strong>ERROR:</strong> Cannot quote comment ID #") . $comment_id . __(" as it has been marked as spam.") . "</em>";
		elseif ($qc_settings['comments_other_posts'] == 'no' && $post && $post->ID != $comment->comment_post_ID) 
			$quoted_comment = "<em>" . __("<strong>ERROR:</strong> Cannot quote comment ID #") . $comment_id . __(" as it is from another post and cross-post quoting is currently disabled.") . "</em>";

		// All is go, let's create 'er!
		else {
			// Create the byline (not using array()'s for the replace items as supposedly some have had issues with that)
			$byline = str_replace('[name]', $comment->comment_author, $qc_settings['byline']);
			$byline = str_replace('[date]', apply_filters('get_comment_date', mysql2date(get_settings('date_format'), $comment->comment_date)), $byline);
			$byline = str_replace('[time]', apply_filters('get_comment_time', mysql2date(get_settings('time_format'), $comment->comment_date)), $byline);

			// This is for the custom date/time format tag in the byline
			while (strpos($byline, '[dt ') !== FALSE) {
				// Get the format to use
				$start_of_format = strpos($byline, '[dt ') + 4; // Where the format starts, 4 = strlen('[dt ');
				$end_of_format = strpos($byline, ']', $start_of_format); // Where the format ends
				$format = substr($byline, $start_of_format, $end_of_format - $start_of_format);

				$byline = substr_replace($byline, mysql2date($format, $comment->comment_date), $start_of_format - 4, $end_of_format + 1 - ($start_of_format - 4));
			}

			// Create the permalink to the quoted comment
			$comment_permalink = get_permalink($comment->comment_post_ID) . '#comment-' . $comment->comment_ID;

			// Removed nested quoted comments if need be
			if ($qc_settings['allow_nested_quotes'] == 'no') {
				$comment_content = $comment->comment_content;
				while (strpos($comment_content, $before_id) !== FALSE) {
					$replace_start = strpos($comment_content, $before_id);
					$replace_end = strpos($comment_content, $after_id) + strlen($after_id);
					$comment_content = substr_replace($comment_content, '', $replace_start, $replace_end - $replace_start);
				}
			} else {
				$comment_content = $comment->comment_content;
			}

			// Now put it all together
			if ($qc_settings['byline_location'] != 'before') {
				$quoted_comment = $comment_content . "\n\n" . '<a href="' . $comment_permalink . '" title="' . $qc_settings['byline_link_title'] . '">' . $byline . '</a>';
			} else {
				$quoted_comment = '<a href="' . $comment_permalink . '" title="' . $qc_settings['byline_link_title'] . '">' . $byline . "</a>\n\n" . $comment_content;
			}
		}

		// Replace the <!-- stuff --> with the actual comment
		$content = substr_replace($content, "<blockquote class='comment_quote'>$quoted_comment</blockquote>\n\n", $start_of_id - strlen($before_id), $end_of_id + strlen($after_id) - ($start_of_id - strlen($before_id)));
	}

	return $content;
}

?>
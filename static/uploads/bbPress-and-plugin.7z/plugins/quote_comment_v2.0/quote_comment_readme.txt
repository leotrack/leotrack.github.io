
=== QUOTE COMMENT v2.0 ===

http://www.viper007bond.com/wordpress-plugins/quote-comment/

by Viper007Bond ( http://www.viper007bond.com/ )


== DESCRIPTION ==

This plugin allows commenters to quote other comments in their reply.

Example: http://www.viper007bond.com/wordpress-plugins/quote-comment/#comments

It is highly cofigurable, all via an admin area options page. The formatting of past quotes can also now be changed as the quote replacements, as of plugin version 2.0, are replaced at the time of diplay rather than the time of quoting.


== INSTALLATION ==

Upload to your plugins folder, usually `wp-content/plugins/`, and activate it on the plugin page.

Edit your theme's `comments.php` file. Add this somewhere in the comment loop, where you'd like the quote link to show up (a good place is after the comment's byline):

	<?php if (function_exists('quote_comment')) { quote_comment(); } ?>


OPTIONAL (Advanced Users Only):

If you'd like to change how the quote placeholder appears (default is "[Comment ID #123 Will Be Quoted Here]"), edit the source of the plugin. Right at the top are two variables that you can change. Please note that you should only change these before using the plugin. If you change it later on, the old placeholders won't be replaced as this plugin only searches for placeholders matching the current structure.


== CONFIGURATION ==

To configure this plugin, go to Options -> Quote Comment in your admin area. That page should be pretty self explanitory.


== OPTIONAL FUNCTION OVERRIDE ==

If you'd like to override the options set on the options page (say you wanted the "Quote" link to appear differently in different themes), the function accepts parameters. See the options page for item defintions.

	* Link Contents

	* Before Link

	* After Link

	* Link Title


== SUPPORT ==

If you've read over this readme carefully and are still having issues, if you've discovered a bug, or have a feature request, please visit this URL:

http://www.viper007bond.com/wordpress-plugins/forums/viewforum.php?id=18
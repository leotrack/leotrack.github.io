Ultimate Tag Warrior 3 / A Wordpress plugin for Tagging and Folksonomy Madness
Written by Christine Davis / christine@neato.co.nz / http://www.neato.co.nz

What's here,  in this archive?

+- plugins
|+- UltimateTagWarrior
||  These are the main plugin files.  Place the whole folder into the wordpress
||  plugins folder (i.e. so you end up with /wp-content/plugins/UltimateTagWarrior/xxx.php
||  and so on).
||+- ultimate-tag-warrior-help.html contains the instructions for installing 
|    the plugin, and how to use it.  It links to help files that cover customisations.
|
+- themes
|+- example-bits
||+- header.php includes the php you need to include the name of the tags in 
||   the title bar, if you're looking at a tag page
||+- tag.php is an example of a tag page - the page that is displayed when you
||   select a tag.
||+- searchtags.php is an AJAX driven tag based search.  To use this,  add it 
||   to your theme folder;  then create a new page, and select the "Search Tags"
||   template.  If your wordpress isn't installed at the top level,  you'll 
||   need to tweak the ajax file path.  You might also need to shuffle headers,
||   footers and sidebars about to match your theme.
||+- tags.php is an example of a page template that displays a tag cloud.  As 
     with the tag search,  to use it, you need to create a new page, and select
     the "Tag Archive" template.
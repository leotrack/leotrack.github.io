<?php
/*
	Template name: Post Archives (requires Extended Live Archives plugin)
*/
?>
<?php get_header(); ?>


<div id="content"><!-- Post Div-->

                        <h2 id="post-<?php the_ID(); ?>">
			<?php _e("Live Archives[Loading...Please Wait]"); ?>
                        </h2>

<p><?php _e("This Is Live Archive Page.."); ?></p><br />
<h3>View By Tags</h3>
<p><?php UTW_ShowWeightedTagSet("sizedtagcloud") ?></p>
<h3>View By Archives</h3>
			<p><?php if (function_exists('af_ela_super_archive')) {af_ela_super_archive();} ?></p>


			<div style='clear: both;'></div>
			<br /><br />

                        </div><!-- End of post div-->
<?php get_footer(); ?>

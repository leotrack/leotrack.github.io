<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/11">
	<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
	
	<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>" />
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats please -->

	<style type="text/css" media="screen">
		@import url(<?php bloginfo('stylesheet_url'); ?>);
				.dl {
			border: 1px solid #ccc;
			display: block;
			margin-right: 1em;
			background: rgb(228, 243, 225);
			width: 255px;
			font-size: 26px;
			text-align: center;
			padding: 1em 0;
			float: left;
			margin-bottom: 1em;
			line-height: 1.2em;
		}
		#content { border-right: 0; }
#comment_quicktags {
	text-align: left;
	margin-left: 1%;
}
#comment_quicktags #ed_comment_toolbar {
	display: inline;
}
#comment_quicktags input.ed_button {
	background: #F4F4F4;
	border: 1px solid #D6D3CE;
	color: #000000;
	font-family: Georgia, "Times New Roman", Times, serif;
	margin: 1px 2px;
padding:0 1px;
	width: auto;
}
#comment_quicktags input:focus.ed_button {
	background: #FFFFFF;
	border: 1px solid #686868;
}
#comment_quicktags #ed_strong {
	font-weight: bold;
}
#comment_quicktags #ed_em {
	font-style: italic;
}
		</style>
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
    <?php wp_get_archives('type=monthly&format=link'); ?>
	<?php //comments_popup_script(); // off by default ?>
	<?php wp_head(); ?>
</head>

<body>
<div id="mini-nav">
	<!-- begin subscribe -->
<script type="text/javascript">
<!--
	function showhide(targetID) {
		//change target element mode
		var elementmode = document.getElementById(targetID).style;
		elementmode.display = (!elementmode.display) ? 'none' : '';
	}

	function changetext(changee,oldText,newText) {
		//changes text in source element
		var elementToChange = document.getElementById(changee);
		elementToChange.innerHTML = (elementToChange.innerHTML == oldText) ? newText : oldText;
	}

	function workforchange(targetID,sourceID,oldContent,newContent) {
		showhide(targetID);
		changetext(sourceID,oldContent,newContent);
	}

	// Cruft note: The content of "oldContent," the third argument of the
	// workforchange() function, must match the existing content of the changer text.

// -->
</script>
<span style="color:#56A5EC;"><a href="javascript:workforchange('subscribe','changer2','—','—');" id='changer2' title="Subcrible RSS">—</a></span>
<span id='subscribe' style='display:none'><!-- begin subscribe -->
<a href="http://feeds.feedburner.com/Zhu8" title="FeedBurner RSS"><img src="<?php bloginfo('template_url'); ?>/images/feedburner.png"></a><br /><a href="http://fusion.google.com/add?feedurl=http://feeds.feedburner.com/Zhu8" title="Google Reader/IG"><img src="<?php bloginfo('template_url'); ?>/images/google-reader.png"></a><br /><a href="http://www.bloglines.com/sub/http://feeds.feedburner.com/Zhu8" title="Bloglines"><img src="<?php bloginfo('template_url'); ?>/images/bloglines.png"></a><br /><a href="http://www.live.com/?add=http://feeds.feedburner.com/Zhu8" title="Windows Live!"><img src="<?php bloginfo('template_url'); ?>/images/windows-live.png"></a><br /><a href="http://www.zhuaxia.com/add_channel.php?url=http://feeds.feedburner.com/Zhu8" title="ZhuaXia"><img src="<?php bloginfo('template_url'); ?>/images/zhuaxia.png"></a><br /><a href="http://www.rojo.com/add-subscription?resource=http://feeds.feedburner.com/Zhu8" title="Rojo"><img src="<?php bloginfo('template_url'); ?>/images/rojo.png"></a>
<!-- end subscribe --></span>
<!-- end subscribe -->
	<a href="<?php bloginfo('url'); ?>/"><img src="<?php bloginfo('template_url'); ?>/images/icon_home.gif" title="Home" /></a>
	<a href="<?php bloginfo('url'); ?>/about/"><img src="<?php bloginfo('template_url'); ?>/images/icon_user.gif" title="About" /></a>
	<a href="#search"><img src="<?php bloginfo('template_url'); ?>/images/icon_search.gif" title="Search" /></a>
	<?php if( is_single() ) { ?>
	<a href="#bookmarks"><img src="<?php bloginfo('template_url'); ?>/images/icon_favourites.gif" title="Favourites..." /></a>
	<a href="#comments"><img src="<?php bloginfo('template_url'); ?>/images/comment.gif" title="View Comment" /></a>
	<a href="#respond"><img src="<?php bloginfo('template_url'); ?>/images/comment_new.gif" title="Add Your Comment" /></a>
<?php } ?>
	<a href="http://www.getfirefox.com/"><img src="<?php bloginfo('template_url'); ?>/images/application_firefox.gif" title="Get Firefox! and F.U.C.K IE" /></a>
	<a href="#top"><img src="<?php bloginfo('template_url'); ?>/images/arrow_up.gif" title="Go Top" /></a>
</div>
<div id="rap">
<h1 id="head"><a href="<?php bloginfo('url'); ?>/"><?php bloginfo('name'); ?></a></h1>
<a name="top"></a><h2 id="tag"><?php bloginfo('description'); ?></h2>
<?php get_sidebar(); ?>
<div id="content">	
<!-- end header -->
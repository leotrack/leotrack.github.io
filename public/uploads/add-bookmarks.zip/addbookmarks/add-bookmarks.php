<?php
/*
Plugin Name: Add Bookmarks
Version: 0.4
Plugin URI: http://www.zhu8.net/blog/2006/09/wordpress_plugin_add_bookmarks.html
Description: Help your visitors to add your entry to Social Bookmark like Blogmarks,delicious,Furl,Yahoo,Google,Baidu,QQ,Techmorati and so on..
(You can add by your self <strong>very simply</strong>,You can choice either <strong>TEXT</strong> or <strong>ICON</strong>)
Author: Zhu8
Author URI: http://www.zhu8.net/
*/

function add_bookmarks() {

// you can start edit here. //

$createKind = "icon";  // links : TEXT - icon : IMAGE ICON

$beforeall = "<b>Add To</b> "; // Show before all  
$beforeeach = "&nbsp;"; // show at the front of every Bookmark
$aftereach = "&nbsp;"; // show at the end of every Bookmark
$afterall = ""; // Show after all

// which one you want to show
// 0=NO 1=YES

$a0 = "1"; // Blogmarks
$a1 = "1"; // del.icio.us
$a2 = "1"; // Furl
$a3 = "1"; // Yahoo!
$a4 = "1"; //365key
$a5 = "1"; //Google Bookmarks
$a6 = "1"; //Baidu Cang
$a7 = "1"; //diglog
$a8 = "1"; //Fanfou
$a9 = "1"; //QQ Bookmarks
$a10 = "1"; //Technorati Favorite This!

// Edit only you want to change one of those bookmarks to another //

if ($createKind == "links") {
$button0 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://blogmarks.net/my/marks,new?mini=1'+'&title='+encodeURIComponent(document.title)+'&url='+encodeURIComponent(location.href)+'&summary='+encodeURIComponent(q)+'&via='+encodeURIComponent(r),'blogmarks','location=no,toolbar=no,scrollbars=yes,width=350,height=450,status=no'));\" title=\"Add to Blogmarks\">Blogmarks</a>";
$button1 = "<a href=\"http://del.icio.us/post\" onclick=\"window.open('http://del.icio.us/post?v=4&amp;noui&amp;jump=close&amp;url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title), 'delicious','toolbar=no,width=700,height=400'); return false;\" title=\"Add to del.icio.us\">del.icio.us</a>";
$button2 = "<a href=\"javascript:(function(){var%20s=document.createElement('script');s.setAttribute('src','http://www.furl.net/resources/furlItComplete.jsp');s.setAttribute('type','text/javascript');document.getElementsByTagName('head')[0].appendChild(s);})();\" title=\"Add to Furl\">Furl</a>";
$button3 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://myweb.cn.yahoo.com/popadd.html?url='+encodeURIComponent(document.location.href)+'&title='+encodeURIComponent(document.title), 'Yahoo','scrollbars=yes,width=780,height=455,left=80,top=80,status=yes,resizable=yes'));\" title=\"Add to Yahoo Myweb\"><font color=\"red\">Yahoo!</font><sup>+</sup></a>";
$button4 = "<a href=\"javascript:d=document;t=d.selection?(d.selection.type!='None'?d.selection.createRange().text:''):(d.getSelection?d.getSelection():'');void(keyit=window.open('http://www.365key.com/storeit.aspx?t='+escape(d.title)+'&u='+escape(d.location.href)+'&c='+escape(t),'keyit','scrollbars=no,width=475,height=575,left=75,top=20,status=no,resizable=yes'));keyit.focus();\" title=\"Add to 365key\"><font color=\"DarkOrchid\">365K<font color=\"#57c200\">e</font>y</font></a>";
$button5 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://www.google.com/bookmarks/mark?op=add&bkmk='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title),'Google','location=no,toolbar=no,scrollbars=yes,width=700,height=450,status=no'));\" title=\"Add to Google BookMarks\">Google</a>";
$button6 = "<a href=\"javascript:u=location.href;t=document.title;c = %22%22 + (window.getSelection ? window.getSelection() : document.getSelection ? document.getSelection() : document.selection.createRange().text);var url=%22http://cang.baidu.com/do/add?it=%22+encodeURIComponent(t)+%22&iu=%22+encodeURIComponent(u)+%22&dc=%22+encodeURIComponent(c)+%22&fr=ien#nw=1%22;window.open(url,%22_blank%22,%22scrollbars=no,width=600,height=450,left=75,top=20,status=no,resizable=yes%22); void 0\" title=\"Add to Baidu\">Baidu</a>";
$button7 = "<a title=\"Add to diglog.com\" href=\"javascript://\" onclick=\"javascript:d=document;t=d.selection?(d.selection.type!='None'?d.selection.createRange().text:''):(d.getSelection?d.getSelection():'');void(keyit=window.open('http://www.diglog.com/submit.aspx?title='+escape(d.title)+'&url='+escape(d.location.href)+'&description='+escape(t),'keyit','scrollbars=yes,width=940,height=600,left=65,top=20,status=no,resizable=yes'));keyit.focus();\">diglog!</a>";
$button8 = "<a title=\"Share to Fanfou\" href=\"javascript:var d=document,w=window,f='http://fanfou.com/share',l=d.location,e=encodeURIComponent,p='?u='+e(l.href)+'?t='+e(d.title)+'?d='+e(w.getSelection?w.getSelection().toString():d.getSelection?d.getSelection():d.selection.createRange().text)+'?s=bl';if(!w.open(f+'r'+p,'sharer','toolbar=0,status=0,width=600,height=400')){l.href=f+'.new'+p;}void(0)\">Fanfou</a>";
$button9 = "<a title=\"QQ bookmarks\" href=\"javascript:window.open('http://shuqian.qq.com/post?from=3&title='+encodeURIComponent(document.title)+'&uri='+encodeURIComponent(document.location.href)+'&jumpback=2&noui=1','favit','width=930,height=470,left=50,top=50,toolbar=no,menubar=no,location=no,scrollbars=yes,status=yes,resizable=yes');void(0)\">QQ</a>";
$button10 = "<a title=\"Technorati Favorite This!\" href=\"http://technorati.com/faves?sub=favthis&add=".get_settings('siteurl')."\">Fav</a>";
$buttons = 11; // the number of bookmarks plus ONE
$counter = 0;
$button = '$button';

echo ("<a href=\"http://www.zhu8.net/blog/2006/09/wordpress_plugin_add_bookmarks.html\"><img src=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/add2myweb.gif\" border=\"0\" title=\"Add Bookmarks Plugin By Zhu8\"></a> ");
echo ($beforeall);
while ($counter < $buttons) {
	if (${'a' . $counter}) {
	// prints rss button
	$printbutton = ${'button' . $counter};
	echo ($beforeeach);
	echo($printbutton."\n");
	echo ($aftereach);
	}
	$counter = $counter+1;
}
echo ($afterall);
}
if ($createKind == "icon") {
$button0 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://blogmarks.net/my/marks,new?mini=1'+'&title='+encodeURIComponent(document.title)+'&url='+encodeURIComponent(location.href)+'&summary='+encodeURIComponent(q)+'&via='+encodeURIComponent(r),'blogmarks','location=no,toolbar=no,scrollbars=yes,width=350,height=450,status=no'));\" title=\"Add to Blogmarks\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/blogmarks.png\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button1 = "<a href=\"http://del.icio.us/post\" onclick=\"window.open('http://del.icio.us/post?v=4&amp;noui&amp;jump=close&amp;url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title), 'delicious','toolbar=no,width=700,height=400'); return false;\" title=\"Add to del.icio.us\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/delicious.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button2 = "<a href=\"javascript:(function(){var%20s=document.createElement('script');s.setAttribute('src','http://www.furl.net/resources/furlItComplete.jsp');s.setAttribute('type','text/javascript');document.getElementsByTagName('head')[0].appendChild(s);})();\" title=\"Add to Furl\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/furl.png\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button3 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://myweb.cn.yahoo.com/popadd.html?url='+encodeURIComponent(document.location.href)+'&title='+encodeURIComponent(document.title), 'Yahoo','scrollbars=yes,width=780,height=455,left=80,top=80,status=yes,resizable=yes'));\" title=\"Add to Yahoo!\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/yahoo.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button4 = "<a href=\"javascript:d=document;t=d.selection?(d.selection.type!='None'?d.selection.createRange().text:''):(d.getSelection?d.getSelection():'');void(keyit=window.open('http://www.365key.com/storeit.aspx?t='+escape(d.title)+'&u='+escape(d.location.href)+'&c='+escape(t),'keyit','scrollbars=no,width=475,height=575,left=75,top=20,status=no,resizable=yes'));keyit.focus();\" title=\"Add to 365key\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/365key.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button5 = "<a href=\"javascript:var q='';var r='';if(document.selection)q=document.selection.createRange().text;else if(window.getSelection())q=window.getSelection();if(document.referrer)r=document.referrer;void(open('http://www.google.com/bookmarks/mark?op=add&bkmk='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title),'Google','location=no,toolbar=no,scrollbars=yes,width=700,height=450,status=no'));\" title=\"Add to Google bookmarks\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/google.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button6 = "<a href=\"javascript:u=location.href;t=document.title;c = %22%22 + (window.getSelection ? window.getSelection() : document.getSelection ? document.getSelection() : document.selection.createRange().text);var url=%22http://cang.baidu.com/do/add?it=%22+encodeURIComponent(t)+%22&iu=%22+encodeURIComponent(u)+%22&dc=%22+encodeURIComponent(c)+%22&fr=ien#nw=1%22;window.open(url,'_blank','scrollbars=no,width=600,height=450,left=75,top=20,status=no,resizable=yes'); void 0\" title=\"Add to Baidu\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/baidu.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button7 = "<a title=\"diglog.com\" href=\"javascript://\" onclick=\"javascript:d=document;t=d.selection?(d.selection.type!='None'?d.selection.createRange().text:''):(d.getSelection?d.getSelection():'');void(keyit=window.open('http://www.diglog.com/submit.aspx?title='+escape(d.title)+'&url='+escape(d.location.href)+'&description='+escape(t),'keyit','scrollbars=yes,width=940,height=600,left=65,top=20,status=no,resizable=yes'));keyit.focus();\"><IMG SRC=\"http://www.diglog.com/images/diglog_thrumb_1.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button8 = "<a title=\"Share to Fanfou\" href=\"javascript:var d=document,w=window,f='http://fanfou.com/share',l=d.location,e=encodeURIComponent,p='?u='+e(l.href)+'?t='+e(d.title)+'?d='+e(w.getSelection?w.getSelection().toString():d.getSelection?d.getSelection():d.selection.createRange().text)+'?s=bl';if(!w.open(f+'r'+p,'sharer','toolbar=0,status=0,width=600,height=400')){l.href=f+'.new'+p;}void(0)\"><IMG SRC=\"http://static.fanfou.com/img/icon.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button9 = "<a title=\"QQ bookmarks\" href=\"javascript:window.open('http://shuqian.qq.com/post?from=3&title='+encodeURIComponent(document.title)+'&uri='+encodeURIComponent(document.location.href)+'&jumpback=2&noui=1','favit','width=930,height=470,left=50,top=50,toolbar=no,menubar=no,location=no,scrollbars=yes,status=yes,resizable=yes');void(0)\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/qqadd.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$button10 = "<a title=\"Technorati Favorite This!\" href=\"http://technorati.com/faves?sub=favthis&add=".get_settings('siteurl')."\"><IMG SRC=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/bookmark-technorati.gif\" WIDTH=\"16\" HEIGHT=\"16\" BORDER=\"0\"></a>";
$buttons = 11; // the number of bookmarks plus ONE
$counter = 0;
$button = '$button';

echo ("<a href=\"http://www.zhu8.net/blog/2006/09/wordpress_plugin_add_bookmarks.html\"><img src=\"".get_settings('siteurl')."/wp-content/plugins/add-bookmarks/icon/add2myweb.gif\" border=\"0\" title=\"Add Bookmarks Plugin By Zhu8\"></a> ");
echo ($beforeall);
while ($counter < $buttons) {
	if (${'a' . $counter}) {
	// prints rss button
	$printbutton = ${'button' . $counter};
	echo ($beforeeach);
	echo($printbutton."\n");
	echo ($aftereach);
	}
	$counter = $counter+1;
}
echo ($afterall);
}
}
?>
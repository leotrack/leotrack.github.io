﻿Add Bookmarks for Wordpress
Plugin Name: Add Bookmarks
Version: 0.4 (Last update:2008/03/18)
Description: Help your visitors to add your entry to Social Bookmark like Blogmarks,delicious,Furl,Yahoo,Google,Baidu,QQ,Techmorati and so on..
(You can add by your self very simply,You can choice either TEXT or ICON)
Requires at least: Wordpress 1.5
Tested up to: Wordpress 2.5-beta1
Author: Zhu8
Plugin URI: http://www.zhu8.net/blog/2006/09/wordpress_plugin_add_bookmarks.html
Download:add-bookmarks.zip
Usage:1) Upload the folder to the /wp-content/plugins/.
2) Active it .Add <?php if(function_exists('add_bookmarks')) { add_bookmarks(); } ?> to where you want to put (I put it insingle.php before <p class="postmetadata">) .DONE!
3)If you want to Add Your Bookmarks,open *add-bookmarks.php* and config it in your Editor(as Editplus,Notepad++) in UTF-8.